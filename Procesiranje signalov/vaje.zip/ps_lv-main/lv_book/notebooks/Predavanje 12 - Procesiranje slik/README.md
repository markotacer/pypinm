# Procesiranje slik za meritve v eksperimentalni modalni analizi

Material (izvorna koda, podatki) predavanja "Procesiranje slik za meritve v eksperimentalni modalni analizi" pri predmetu Procesiranje signalov.