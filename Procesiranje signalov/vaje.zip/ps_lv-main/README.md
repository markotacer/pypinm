# ps_lv

[![Jupyter Book Badge](https://jupyterbook.org/badge.svg)](https://domengorjup.github.io/ps_lv/)

Repozitorij interaktivnih predlog laboratorijskih vaj pri predmetu Procesiranje signalov.

Predloge lahko berete tudi v obliki [spletne knjige](https://domengorjup.github.io/ps_lv/).