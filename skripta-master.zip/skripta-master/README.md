========
Fotonika
========

Tu se nahaja skripta za predmeta Fotonika 1 in Fotonika 2 na II. stopnji univerzitetnega programa fizike na Fakulteti za Matematiko in Fiziko, Univerze v Ljubljani. 
 
Skripta je nastala na osnovi skripte za Elektrooptiko (kasneje preimenovano v Fotoniko, kasneje razdeljeno na Fotoniko 1 in Fotoniko 2) prof. Martina Čopiča, ki se nahaja na  <http://fiz.fmf.uni-lj.si/%7Etine/fotonika.pdf>.

Avtorji
-------

* Martin Čopič
* Mojca Vilfan
* Andrej Petelin

Navodila za pripravo pdf-ja
---------------------------

Uporabi `pdflatex` saj so določene slike v `pdf` formatu.

